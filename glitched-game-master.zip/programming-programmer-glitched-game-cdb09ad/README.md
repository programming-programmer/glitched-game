# glitched-game

This is a beginner project that utilizes Godot Engine to create a play-to-escape game.
